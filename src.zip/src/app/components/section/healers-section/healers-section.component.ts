import { Component } from '@angular/core';

@Component({
  selector: 'app-healers-section',
  templateUrl: './healers-section.component.html',
  styleUrls: ['./healers-section.component.scss']
})
export class HealersSectionComponent {

}
