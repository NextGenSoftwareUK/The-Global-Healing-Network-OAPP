import { Component } from '@angular/core';

@Component({
  selector: 'app-healing-tags',
  templateUrl: './healing-tags.component.html',
  styleUrls: ['./healing-tags.component.scss']
})
export class HealingTagsComponent {

}
