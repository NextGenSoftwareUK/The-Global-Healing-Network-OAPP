import { Component } from '@angular/core';

@Component({
  selector: 'app-healing-forum',
  templateUrl: './healing-forum.component.html',
  styleUrls: ['./healing-forum.component.scss']
})
export class HealingForumComponent {

}
