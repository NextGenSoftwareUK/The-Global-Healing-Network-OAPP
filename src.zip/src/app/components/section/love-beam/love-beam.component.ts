import { Component } from '@angular/core';

@Component({
  selector: 'app-love-beam',
  templateUrl: './love-beam.component.html',
  styleUrls: ['./love-beam.component.scss']
})
export class LoveBeamComponent {

}
